This mod adds a pet duck to your game. It is available in the ingame store.
Your new pet duck will follow you on your adventure and is able to grab one item.

<h1>What's New?</h1>

- The duck's speed now depends on player's speed.
- If the duck is too far away, it can now run to get to the player faster.
- You can now let the duck drop its item. Just Get close to the duck and hold down the [E] key.
- Some new animations just for fun.

<h1>Installation</h1>

- Install BepInEx.
- Place the DuckMod folder in your BepInEx/plugins/ folder.
- Everyone joining needs this mod installed.