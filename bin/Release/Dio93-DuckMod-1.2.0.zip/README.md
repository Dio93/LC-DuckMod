This mod adds a pet duck to your game. It is available in the ingame store.
Your new pet duck will follow you on your adventure and is able to grab one item.

If you like my work please consider supporting me on [Ko-fi](https://ko-fi.com/dio93) :)

<h1>What's New?</h1>

- There is now a config file in BepInEx/config/. <br> **Make sure all players have the same configs.** <br>The following settings can be made:
    - The maximum number of ducks (if you buy more ducks than you can have you will still lose your money without getting more ducks)
    - Price of ducks
    - How many items a duck can carry
    - The ducks speed
    - Is it hittable by players? (it can die if true)
    - Health points (irrelevant if hittable set to false)
    - Logging into terminal (false by default)
- There are two different types of duck you can buy now
- Several fixes

<h1>Known issues</h1>

- There are still some sync issues when you start/ land the ship
- Ducks can't grab dead players
- You can't grab dead ducks :(

<h1>Installation</h1>

- Install BepInEx.
- Place the DuckMod folder in your BepInEx/plugins/ folder.
- Everyone joining needs this mod installed.