<h1>Readme</h1>

This mod adds a pet duck to your game. It is available in the ingame store.
Your new pet duck will follow you on your adventure and is able to grab one item.

<h1>Installation</h1>

- Install BepInEx.
- Place the DuckMod folder in your BepInEx/plugins/ folder.
- Everyone joining needs this mod installed.